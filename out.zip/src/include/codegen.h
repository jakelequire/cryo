#ifndef CODEGEN_H
#define CODEGEN_H

#include "ir.h"

int generate_code(IRInstruction* ir);

#endif // CODEGEN_H