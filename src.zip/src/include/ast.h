#include <stdio.h>
#include <stdlib.h>

#include "lexer.h"
#include "parser.h"

void printAST(ASTNode* node);

void printASTIndented(ASTNode* node, int indent);
