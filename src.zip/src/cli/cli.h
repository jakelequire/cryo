#include <stdio.h>

int cryo(int argc, char** argv);
