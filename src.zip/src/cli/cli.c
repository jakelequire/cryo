#include <stdio.h>


int cryo(int argc, char** argv) {
    printf("Hello, world! (from cryo)\n");
    return 0;
}

